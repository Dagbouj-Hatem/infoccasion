<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockadvertising}prestashop>blockadvertising_bedd646b07e65f588b06f275bd47be07'] = 'Advertising block';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_dc23a0e1424eda56d0700f7ebe628c78'] = 'Adds an advertisement block to selected sections of your e-commerce website.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_b15e7271053fe9dd22d80db100179085'] = 'This module need to be hooked in a column and your theme does not implement one';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'File upload error.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_89ca5c48bbc6b7a648a5c1996767484c'] = 'Block image';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_05177d68c546e5b754e39ae3ce211cc2'] = 'Image will be displayed as 155 pixels by 163 pixels.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Image link';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Title';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_c9cc8cce247e49bae79f15173ce97354'] = 'Save';


return $_MODULE;
