<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Баннер блок';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Отображает баннер в верхней части магазина.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'ошибка при загрузке файла';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Настройки обновлены';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Изображение верхнего баннера';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Загрузите изображение для вашего верхний баннера. Рекомендуемые размеры 1170 х 65 пикселей, если вы используете стандартную тему.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Ссылка банера';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Введите ссылку, связанную с вашим баннером. При нажатии на баннер, ссылка откроется в том же окне. Если ссылка не будет указанна, откроется главная страница.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Описание баннера';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Пожалуйста, введите короткий, но значимое описание для баннера.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
