<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Blok bannera';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Wyświetla banner na górze sklepu.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'błąd poczas wysyłania pliku';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia są zaktualizowane';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Baner górny obraz';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Prześlij zdjęcie swojej górnej wstęgi. Zalecane wymiary to 1170 x 65PX jeśli używasz domyślnego motywu.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Odsyłacz';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Wpisz adres internetowy powiązany z banerem. Po kliknięciu na banner, link, otwiera się w tym samym oknie. Jeśli żadne połączenie nie zostanie wprowadzony, to przekierowuje do strony głównej.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Opis banner';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Proszę podać krótki, ale treściwy opis banera.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
